function roll() {
    t=true
    while t:
        switch (rand(1,3)){
            case 1:
                //
            case 2:
                //
            case 3:
                //
        }
}
function rand(min,max) {
    return Math.floor(Math.random()*max)+min
}